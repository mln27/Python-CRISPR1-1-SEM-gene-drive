# This module runs the CRISPR one-target location to one-target location using the equations generated and parameters
# set in the input file
#
# Model developed by Martial Ndeffo (m.ndeffo@tamu.edu)

import pandas as pd
import numpy as np
import random
import time
import Yellow_Drive_Equations

def Yellow_Drive_Progression():


# stage duration and growth rate parameters
    T_e = 1
    T_l = 4
    T_p = 5
    r_m = 1.196
    mu_e = 0.15
    mu_p = 0.15
    mu_ad = 0.263
    cols = ['w', 'v', 'u', 'r', 'g', 's', 'ww', 'wv', 'wu', 'wr', 'wg', 'ws', 'vv', 'vu', 'vr', 'vg', 'vs', 'uu', 'ur', 'ug', 'us', 'rr', 'rg', 'rs', 'gg', 'gs', 'ss']
    results_temp = []

    # Reading and assigning values from Excel document
    M = pd.read_excel('Yellow Drive Input Parameters.xlsx')

    sigma = M.iloc[5, 3]
    lamda = M.iloc[6, 3]

    q2 = M.iloc[8, 3]
    q1 = M.iloc[9, 3]
    P2 = M.iloc[10, 3]
    P1 = M.iloc[11, 3]
    delta2 = M.iloc[12, 3]
    delta1 = M.iloc[13, 3]
    epsilon1 = M.iloc[15, 3]
    epsilon2 = M.iloc[14, 3]
    gens = M.iloc[16, 3]
    Ns = M.iloc[17,3]
    
    # Assignment of initial conditions
    g0 = np.array(M.iloc[20:47, 3].values)
    mortRateAdult1 = np.array([mu_ad] * len(cols))
    R_m = r_m**(T_e + T_l + T_p + 1/mu_ad)
    mu_l = 1 - (R_m*mu_ad/(0.5*lamda*(1-mu_ad)))**(1/(T_e + T_l + T_p))
    theta_e = (1-mu_e)**T_e
    theta_l = (1-mu_l)**T_l
    theta_p = (1-mu_p)**T_p
    alpha = (0.5*lamda*theta_e*sum(g0)/(R_m-1))*((1-theta_l/R_m)/(1-(theta_l/R_m)**(1/T_l)))
    developTime = T_e + T_l + T_p
    span = developTime*gens

    alpha1 = M.iloc[0,3]
    gamma1 = M.iloc[1,3]
    alpha2 = M.iloc[2,3]
    gamma2 = M.iloc[3,3]
    
    # Assignment of initial fitness costs
    fitCost = np.array(M.iloc[20:47, 9].values)

    # Assignment of initial fitness costs
    mateCost = np.array(M.iloc[20:47, 14].values)
    
    # recalculate fitness costs
    for index,val in enumerate(fitCost):
        mortRateAdult1[index] = mortRateAdult1[index] * (1 + fitCost[index])
     
 

    # RUN THE MODEL
        
    a = random.sample(range(10000),Ns)
    for ns in range(Ns): 

                    # indexes are day
                    surviving_Adults = [[0 for x in range(len(cols))] for y in range(span)]
                    surviving_Larvae = [[0 for x in range(len(cols))] for y in range(span)]
                    seeded_Larvae = [[0 for x in range(len(cols))] for y in range(span)]
                    seeded_Eggs = [[0 for x in range(len(cols))] for y in range(span)]
                    total_Adults = [[0 for x in range(len(cols))] for y in range(span)]
                    total_Larvae = [[0 for x in range(len(cols))] for y in range(span)]
                    total_Eggs = [[0 for x in range(len(cols))] for y in range(span)]
                    total_population_by_genotype = [[0 for x in range(len(cols))] for y in range(span)]
                    
                    random.seed(a[ns])
                    beta1 = 1 - (alpha1 + gamma1)
                    beta2 = 1 - (alpha2 + gamma2)
                    
                    # loop through each time step
                    start_time = time.time()
                    for T in range(span):
                        if T == 0:
                            total_Adults[0] = g0
                            total_Larvae[0][0] = alpha*(R_m - 1)/2
                            total_Larvae[0][21] = alpha*(R_m - 1)/2
                            proportionPop = convert_to_proportion(g0)
                            rates0 =Yellow_Drive_Equations.Yellow_Drive_Rates(proportionPop, sigma, lamda, delta1, delta2, fitCost, mateCost,
                                                 q1, q2, P1, P2, alpha1, alpha2, beta1, beta2, gamma1, gamma2, epsilon1, epsilon2)
                            seeded_Eggs[0] = [approx_poisson(i) for i in rates0]
                            total_Eggs[T] = [i + j for i, j in zip(total_Eggs[T], seeded_Eggs[T])]
                            
                            #Prior_Eggs is 0 if the population is assumed to be seeded without prior history
                            #rather than having naturally evolved to its equilibrium 
                            Prior_Eggs = [0 for x in range(len(cols))]
                                           
                        elif 0 < T < (T_e+1):
                            
                             # only the initial adults will be producing offspring at this time.
                            surviving_Adults[T] = [approx_binomial(i,j) for i, j in zip(total_Adults[T-1], [(1 - k) for k in mortRateAdult1])]
                           
                            proportionPop = convert_to_proportion(surviving_Adults[T])
                            rates1 = Yellow_Drive_Equations.Yellow_Drive_Rates(proportionPop, sigma, lamda, delta1, delta2, fitCost, mateCost,
                                                 q1, q2, P1, P2, alpha1, alpha2, beta1, beta2, gamma1, gamma2, epsilon1, epsilon2)
                            J2 = [approx_poisson(i) for i in rates1]
                            seeded_Eggs[T] = [i + j for i, j in zip(seeded_Eggs[T], J2)]
                            
                            F_prod = 1
                            for i in range(1,T_l+1):
                                F_prod = F_prod*F(alpha,sum(total_Larvae[0]),T_l)
                                
                            new_pupae = [approx_binomial(i,j) for i, j in zip(Prior_Eggs, [theta_e*theta_l*F_prod for k in range(len(Prior_Eggs))])]
                            surviving_Larvae[T] = [approx_binomial(i,j) for i, j in zip(total_Larvae[T-1], [(1-mu_l)*F(alpha,sum(total_Larvae[T-1]),T_l) for k in range(len(total_Larvae[T-1]))])]
                            seeded_Larvae[T] = [approx_binomial(i,j) for i, j in zip(Prior_Eggs, [theta_e for k in range(len(Prior_Eggs))])]
                            total_Larvae[T] = [max(0,i + j + k - q) for i, j, k, q in zip(total_Larvae[T], surviving_Larvae[T], seeded_Larvae[T], new_pupae)]
                            # new adults create genotypes of
                            F_prod = 1
                            for i in range(1,T_l+1):
                                F_prod = F_prod*F(alpha,sum(total_Larvae[0]),T_l)
                                
                            new_adults = [approx_binomial(i,j) for i, j in zip(Prior_Eggs, [theta_e*theta_l*theta_p*F_prod*(1-mu_ad) for k in range(len(Prior_Eggs))])]
                            total_Adults[T] = [i + j + k for i, j, k in zip(total_Adults[T], surviving_Adults[T], new_adults)]
                            total_Eggs[T] = [i + j for i, j in zip(total_Eggs[T], J2)]
                           
                        
                        elif T_e < T < (T_e + T_l+1):

                             # only the initial adults will be producing offspring at this time.
                            surviving_Adults[T] = [approx_binomial(i,j) for i, j in zip(total_Adults[T-1], [(1 - k) for k in mortRateAdult1])]
                          
                            proportionPop = convert_to_proportion(surviving_Adults[T])
                            rates2 = Yellow_Drive_Equations.Yellow_Drive_Rates(proportionPop, sigma, lamda, delta1, delta2, fitCost, mateCost,
                                                 q1, q2, P1, P2, alpha1, alpha2, beta1, beta2, gamma1, gamma2, epsilon1, epsilon2)
                            J2 = [approx_poisson(i) for i in rates2]
                            seeded_Eggs[T] = [i + j for i, j in zip(seeded_Eggs[T], J2)]
                            
                            F_prod = 1
                            for i in range(1,T_l+1):
                                F_prod = F_prod*F(alpha,sum(total_Larvae[0]),T_l)
                                
                            new_pupae = [approx_binomial(i,j) for i, j in zip(Prior_Eggs, [theta_e*theta_l*F_prod for k in range(len(Prior_Eggs))])]
                            surviving_Larvae[T] = [approx_binomial(i,j) for i, j in zip(total_Larvae[T-1], [(1-mu_l)*F(alpha,sum(total_Larvae[T-1]),T_l) for k in range(len(total_Larvae[T-1]))])]
                            seeded_Larvae[T] = [approx_binomial(i,j) for i, j in zip(seeded_Eggs[T - T_e], [theta_e for k in range(len(seeded_Eggs[T - T_e]))])]
                            total_Larvae[T] = [max(0,i + j + k - q) for i, j, k, q in zip(total_Larvae[T], surviving_Larvae[T], seeded_Larvae[T], new_pupae)]
                            # new adults create genotypes of
                            F_prod = 1
                            for i in range(1,T_l+1):
                                F_prod = F_prod*F(alpha,sum(total_Larvae[0]),T_l)
                                
                            new_adults = [approx_binomial(i,j) for i, j in zip(Prior_Eggs, [theta_e*theta_l*theta_p*F_prod*(1-mu_ad) for k in range(len(Prior_Eggs))])]
                            total_Adults[T] = [i + j + k for i, j, k in zip(total_Adults[T], surviving_Adults[T], new_adults)]
                            total_Eggs[T] = [i + j for i, j in zip(total_Eggs[T], J2)]
                            
                        elif (T_e + T_l) < T < (T_e + T_l + T_p+1):

                             # only the initial adults will be producing offspring at this time.
                            surviving_Adults[T] = [approx_binomial(i,j) for i, j in zip(total_Adults[T-1], [(1 - k) for k in mortRateAdult1])]
                        
                            proportionPop = convert_to_proportion(surviving_Adults[T])
                            rates3 = Yellow_Drive_Equations.Yellow_Drive_Rates(proportionPop, sigma, lamda, delta1, delta2, fitCost, mateCost,
                                                 q1, q2, P1, P2, alpha1, alpha2, beta1, beta2, gamma1, gamma2, epsilon1, epsilon2)
                            J2 = [approx_poisson(i) for i in rates3]
                            seeded_Eggs[T] = [i + j for i, j in zip(seeded_Eggs[T], J2)]
                            F_prod = 1
                            for i in range(1,T_l+1):
                                F_prod = F_prod*F(alpha,sum(total_Larvae[T-i]),T_l)
                            new_pupae = [approx_binomial(i,j) for i, j in zip(seeded_Eggs[T-T_e-T_l], [theta_e*theta_l*F_prod for k in range(len(seeded_Eggs[T-T_e-T_l]))])]
                            surviving_Larvae[T] = [approx_binomial(i,j) for i, j in zip(total_Larvae[T-1], [(1-mu_l)*F(alpha,sum(total_Larvae[T-1]),T_l) for k in range(len(total_Larvae[T-1]))])]
                            seeded_Larvae[T] = [approx_binomial(i,j) for i, j in zip(seeded_Eggs[T - T_e], [theta_e for k in range(len(seeded_Eggs[T - T_e]))])]
                            total_Larvae[T] = [max(0,i + j + k - q) for i, j, k, q in zip(total_Larvae[T], surviving_Larvae[T], seeded_Larvae[T], new_pupae)]
                            # new adults create genotypes of
                            F_prod = 1
                            for i in range(1,T_l+1):
                                F_prod = F_prod*F(alpha,sum(total_Larvae[T-i]),T_l)
                                
                            new_adults = [approx_binomial(i,j) for i, j in zip(seeded_Eggs[0], [theta_e*theta_l*theta_p*F_prod*(1-mu_ad) for k in range(len(seeded_Eggs[0]))])]
                            total_Adults[T] = [i + j + k for i, j, k in zip(total_Adults[T], surviving_Adults[T], new_adults)]
                            total_Eggs[T] = [i + j for i, j in zip(total_Eggs[T], J2)]
                        
                        else:
                        
                            surviving_Adults[T] = [approx_binomial(i,j) for i, j in zip(total_Adults[T-1], [(1 - k) for k in mortRateAdult1])]
                            proportionPop = convert_to_proportion(surviving_Adults[T])
                            rates4 = Yellow_Drive_Equations.Yellow_Drive_Rates(proportionPop, sigma, lamda, delta1, delta2, fitCost, mateCost,
                                                 q1, q2, P1, P2, alpha1, alpha2, beta1, beta2, gamma1, gamma2, epsilon1, epsilon2)
                            J2 = [approx_poisson(i) for i in rates4]
                            seeded_Eggs[T] = [i + j for i, j in zip(seeded_Eggs[T], J2)]
                            # new larvae create genotypes of
                            F_prod = 1
                            for i in range(1,T_l+1):
                                F_prod = F_prod*F(alpha,sum(total_Larvae[T-i]),T_l)
                                
                            new_pupae = [approx_binomial(i,j) for i, j in zip(seeded_Eggs[T-T_e-T_l], [theta_e*theta_l*F_prod for k in range(len(seeded_Eggs[T-T_e-T_l]))])]
                            surviving_Larvae[T] = [approx_binomial(i,j) for i, j in zip(total_Larvae[T-1], [(1-mu_l)*F(alpha,sum(total_Larvae[T-1]),T_l) for k in range(len(total_Larvae[T-1]))])]
                            seeded_Larvae[T] = [approx_binomial(i,j) for i, j in zip(seeded_Eggs[T - T_e], [theta_e for k in range(len(seeded_Eggs[T - T_e]))])]
                            total_Larvae[T] = [max(0,i + j + k - q) for i, j, k, q in zip(total_Larvae[T], surviving_Larvae[T], seeded_Larvae[T], new_pupae)]
                            # new adults create genotypes of
                            F_prod = 1
                            for i in range(1,T_l+1):
                                F_prod = F_prod*F(alpha,sum(total_Larvae[T-i-T_p]),T_l)
                                
                            new_adults = [approx_binomial(i,j) for i, j in zip(seeded_Eggs[T-T_e-T_l-T_p], [theta_e*theta_l*theta_p*F_prod*(1-mu_ad) for k in range(len(seeded_Eggs[T-T_e-T_l-T_p]))])]
                            
                            total_Adults[T] = [i + j + k for i, j, k in zip(total_Adults[T], surviving_Adults[T], new_adults)]
                            total_Eggs[T] = [i + j for i, j in zip(total_Eggs[T], J2)]


                        # Store the values of the model into a list
                        total_population_by_genotype[T] = [i + j for i, j in zip(total_population_by_genotype[T], total_Adults[T])]
                        total_population = sum(total_population_by_genotype[T])

                        male_w_count = total_population_by_genotype[T][0]
                        male_v_count = total_population_by_genotype[T][1]
                        male_u_count = total_population_by_genotype[T][2]
                        male_r_count = total_population_by_genotype[T][3]
                        male_g_count = total_population_by_genotype[T][4]
                        male_s_count = total_population_by_genotype[T][5]

                        female_w_count = 2*total_population_by_genotype[T][6] + sum(total_population_by_genotype[T][7:12])
                        female_v_count = total_population_by_genotype[T][7] + 2*total_population_by_genotype[T][12] + sum(total_population_by_genotype[T][13:17])
                        female_u_count = total_population_by_genotype[T][8] + total_population_by_genotype[T][13] + 2*total_population_by_genotype[T][17] + sum(total_population_by_genotype[T][18:21])
                        female_r_count = total_population_by_genotype[T][9] + total_population_by_genotype[T][14] + total_population_by_genotype[T][18] + 2*total_population_by_genotype[T][21] + sum(total_population_by_genotype[T][22:24])
                        female_g_count = total_population_by_genotype[T][10] + total_population_by_genotype[T][15] + total_population_by_genotype[T][19] + total_population_by_genotype[T][22] + 2*total_population_by_genotype[T][24] + total_population_by_genotype[T][25]
                        female_s_count = total_population_by_genotype[T][11] + total_population_by_genotype[T][16] + total_population_by_genotype[T][20] + total_population_by_genotype[T][23] + total_population_by_genotype[T][25] + 2*total_population_by_genotype[T][26]

                        w_count = (male_w_count + female_w_count) / (1.5*total_population)
                        v_count = (male_v_count + female_v_count) / (1.5*total_population)
                        u_count = (male_u_count + female_u_count) / (1.5*total_population)
                        r_count = (male_r_count + female_r_count) / (1.5*total_population)
                        g_count = (male_g_count + female_g_count) / (1.5*total_population)
                        s_count = (male_s_count + female_s_count) / (1.5*total_population)

                        output_line = [ns, delta1, epsilon1, alpha1, gamma1, delta2, epsilon2, alpha2, gamma2, T, w_count, v_count, u_count, r_count, g_count, s_count, total_population]
                        results_temp.append(output_line)

                    print('Run complete in', time.time() - start_time, 'seconds.')

    # START HERE TO OUTPUT THE DATA
    cols = ['iter', 'male_delta','male_epsilon','male_alpha', 'male_gamma', 'female_delta', 'female_epsilon', 'female_alpha', 'female_gamma', 'time', 'w', 'v', 'u', 'r', 'g', 's', 'total_population']
    results_df = pd.DataFrame(results_temp, columns=cols)

    results_df.to_excel('Yellow_Drive Results.xlsx', index=False)
    
    
# approximate poisson 
def approx_poisson(n, size=None):
    if n < 10e7:
        poisson = np.random.poisson(n)
    else:
        gaussian = np.random.normal(n, (n)**(1/2), size=size)
        # Add the continuity correction to sample at the midpoint of each integral bin.
        gaussian += 0.5
        if size is not None:
            poisson = gaussian.astype(np.int64)
        else:
            # scalar
            poisson = int(gaussian)
    return poisson

# approximate binomial 
def approx_binomial(n, p, size=None):
    if n < 10e4:
        binomial = np.random.binomial(n,p)
    else:
        gaussian = np.random.normal(n*p, (n*p*(1-p))**(1/2), size=size)
        # Add the continuity correction to sample at the midpoint of each integral bin.
        gaussian += 0.5
        if size is not None:
            binomial = gaussian.astype(np.int64)
        else:
            # scalar
            binomial = int(gaussian)
    return binomial
# density dependent process
def F(a,L,T):
    return (a/(a+L))**(1/T)

# converts the list of genotype counts to a proportion by
def convert_to_proportion(K):

    K = [float(i) for i in K]

    males = K[:6]
    females = K[6:]

    male_total = sum(males)

    if male_total != 0:
        males = [m / male_total for m in males]

    output_list = []
    output_list.extend(males)
    output_list.extend(females)

    return output_list


# generates a list of genotypes based on a list of alleles
def generate_allele_combinations(allele_list):

    # create all the combinations of alleles possible
    allele_1_sequence = []
    allele_2_sequence = []

    allele_dels = allele_list.copy()
    for allele in allele_list:
        for remaining_allele in allele_dels:
            allele_1_sequence.append(allele)
        allele_dels.remove(allele)

    allele_dels = allele_list.copy()
    for allele in allele_list:
        for remaining_allele in allele_dels:
            allele_2_sequence.append(remaining_allele)
        allele_dels.remove(allele)

    # combine the two alleles together into a single genotype
    two_allele_combinations = [i + j for i, j in zip(allele_1_sequence, allele_2_sequence)]

    return two_allele_combinations